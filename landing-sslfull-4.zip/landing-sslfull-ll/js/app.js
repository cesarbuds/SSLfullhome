$(function () {
  $('[data-toggle="popover"]').popover({ html : true 
  });

  
 

});


